Accounts.config({
	sendVerificationEmail: true
});