# Slack Clone Built in Meteor.js

Code for the scotch.io tutorial by Daniel (danyll.com)

![](https://cask.scotch.io/2015/05/slack-clone-in-meteor-getting-started.png)
